package com.Test.myWebApp_Test.testConfiguration;

import org.mockito.Mockito;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.Test.myWebApp_Test.service.LoginService;

@Profile("test")
@SpringBootConfiguration
public class TestConfiguration {
	 
	   @Primary
	   public LoginService loginService() {
	      return Mockito.mock(LoginService.class);
	   }
}
