import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.Test.myWebApp_Test.ApplicationTestSpring;
import com.Test.myWebApp_Test.service.LoginService;




@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApplicationTestSpring.class)
public class MockitoDemoApplicationTests {

   @Autowired
   private LoginService loginService;

   @Test
   public void whenUserIdIsProvided_thenRetrievedNameIsCorrect() {
      Mockito.when(loginService.validateUser("Subha","Subha")).thenReturn(true);
    
      Assert.assertEquals("Subha", "Subha");
   }
}